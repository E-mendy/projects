import sqlite3
from tkinter import Tk, simpledialog, messagebox  # Corrected import statement
from termcolor import colored
from datetime import datetime, timedelta
import sys
import random

DB_FILE = "word.db"
WORD_FILE_PATH = "OUTPUT_FILE.txt"
MAX_PLAY_ATTEMPTS = 6

def create_tables():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password TEXT,
            last_played DATETIME,
            successes INT,
            failures INT
        )
    ''')

    # Insert sample users only if the table is newly created
    cursor.execute('SELECT COUNT(*) FROM users')
    user_count = cursor.fetchone()[0]
    if user_count == 0:
        sample_users = [
            ('ellen_user', 'cristal@123'),
            ('cristal_user', 'cristal@12'),
            ('medard_user', 'medard!12'),
            ('jayden_user', 'jayden123')
        ]

        cursor.executemany('INSERT INTO users (username, password, last_played, successes, failures) VALUES (?, ?, NULL, 0, 0)', sample_users)

    conn.commit()
    conn.close()

def create_user(username, password):
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute('INSERT INTO users (username, password, last_played, successes, failures) VALUES (?, ?, NULL, 0, 0)', (username, password))
        conn.commit()
        conn.close()
        messagebox.showinfo("Success", f"User '{username}' created successfully.")
    except Exception as e:
        messagebox.showerror("Error", f"Error creating user: {e}")

def get_user(username):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
    user_data = cursor.fetchone()
    conn.close()
    return user_data

def can_play(username):
    user_data = get_user(username)

    if user_data is None:
        create_new_user = messagebox.askquestion("User Not Found", f"User '{username}' not found. Do you want to create a new user?")
        if create_new_user == 'yes':
            new_password = simpledialog.askstring("Create User", "Enter a new password:")
            create_user(username, new_password)
            return True
        else:
            return False

    last_played = user_data[3]  # Assuming the last_played field is at index 3

    if last_played is None:
        return True  # User never played before

    last_played = datetime.strptime(last_played, "%Y-%m-%d %H:%M:%S")
    time_since_last_play = datetime.now() - last_played

    if time_since_last_play > timedelta(hours=24):
        return True  # User can play because 24 hours have passed since the last play
    else:
        play_count = user_data[4]  # Assuming the play count field is at index 4

        if play_count < MAX_PLAY_ATTEMPTS:
            return True  # User can play because they haven't reached the maximum play attempts
        else:
            messagebox.showinfo("Limit Exceeded", f"Sorry! You've reached the maximum play attempts ({MAX_PLAY_ATTEMPTS}) within the last 24 hours. Try again later.")
            return False

def read_random_word(file_path):
    with open(file_path, 'r') as file:
        word_array = file.read().splitlines()
        return random.choice(word_array)

def update_last_played(username):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET last_played = ?, failures = failures + 1 WHERE username = ?', (datetime.now(), username))
    conn.commit()
    conn.close()

def play_wordle(username):
    word_to_guess = read_random_word(WORD_FILE_PATH)
    max_attempts = 6

    messagebox.showinfo("Welcome", "Let's play Wordle!")
    messagebox.showinfo("Instructions", f"Guess the 5-letter word. You have {max_attempts} attempts.")

    for attempt in range(1, max_attempts + 1):
        guess = simpledialog.askstring("Guess", f"Attempt {attempt}:").lower()

        if len(guess) != 5:
            messagebox.showwarning("Invalid Input", "Please enter a 5-letter word.")
            continue

        sys.stdout.write('\x1b[1A')
        sys.stdout.write('\x1b[2K')

        for i in range(5):
            if guess[i] == word_to_guess[i]:
                print(colored(guess[i], 'green'), end="")
            else:
                print(colored(guess[i], 'red'), end="")
        print()

        if guess == word_to_guess:
            messagebox.showinfo("Congratulations", f"Congratulations! You guessed the word '{word_to_guess}' in {attempt} attempts.")
            update_last_played(username)
            break
    else:
        messagebox.showinfo("Sorry", f"Sorry! You didn't guess the word. It was '{word_to_guess}'.")
        update_last_played(username)

# Add the rest of your functions here

if __name__ == "__main__":
    create_tables()

    root = Tk()
    root.title("Wordle Game")

    username = simpledialog.askstring("Username", "Enter your username:")

    if can_play(username):
        play_wordle(username)
    else:
        messagebox.showinfo("Sorry", "You can't play right now. Try again later.")

    root.mainloop()
