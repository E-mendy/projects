#!/usr/bin/env python
# coding: utf-8

# In[1]:


pip install requests beautifulsoup4 nltk


# In[2]:


pip install PyMuPDF


# In[3]:


import fitz  # PyMuPDF
from nltk import word_tokenize
from nltk import pos_tag

def read_ebook(file_path):
    doc = fitz.open(file_path)
    text = ""
    for page_number in range(doc.page_count):
        page = doc[page_number]
        text += page.get_text()
    return text

# ... (rest of the code remains the same)

# Example usage
ebook_file_path = 'The-Unveiling.pdf'
output_file_path = 'OUTPUT_FILE.txt'

ebook_text = read_ebook(ebook_file_path)
result = extract_5_letter_nouns(ebook_text)
save_to_file(result, output_file_path)

print(f"Unique 5-letter nouns extracted and saved to {output_file_path}")


# In[6]:


pip install termcolor


# In[ ]:





# In[ ]:




